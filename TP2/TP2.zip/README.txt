LISEZ-MOI:

Cette assignation contient, et n�cessite 5 fichiers pour ex�cuter ce programme. Ils sont les suivants:

TP2.py # file principale
BoxClass.py
GenBinTrees.py
BinaryTreeSeeder.py
OptimalAreaFinder.py

essai montrent une ex�cution d'environ 90-100 secondes, et il devrait prendre les noms d'objets de plus de 1 caract�re.

il ne sera pas g�n�rer tous les arbres binaires. J'ai pu sauver ex�cution d'ex�cution en sachant que la m�che ci-dessous, par exemple, sont identiques et retuen la m�me r�ponse.

'10:(-,A,B):35' == '01:(|,A,B):35'
'10:(-,B,A):35' == '01:(|,B,A):35'


README:

This assignment contains, and requires 5 files to run this program.  they are:

TP2.py  # Main File
BoxClass.py
GenBinTrees.py
BinaryTreeSeeder.py
OptimalAreaFinder.py

test show a runtime of about 90-100 seconds, and it should take object names of more than 1 character.  

it will not generate all binary trees.  I was able to save runtime execution by knowing that the tress below, for example, are identical and will retuen the same answer.

'10:(-,A,B):35' == '01:(|,A,B):35'
'10:(-,B,A):35' == '01:(|,B,A):35'